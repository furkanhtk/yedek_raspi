import Encoder

enc = Encoder.Encoder(17, 27)
while True:
   print(enc.read())
